package com.loiane.cursojava.aula38;

public class Teste {

}
