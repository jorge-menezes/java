/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.loiane.cursojava.aula35.labs;

/**
 *
 * @author loiane
 */
public class Exer01 {
    
    public static void main(String[] args) {
        
        for (int i=0; i<20; i++){
            System.out.print(Calculadora.fibonacci(i) + " ");
        }
        
        
    }
}
