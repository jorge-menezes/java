package com.loiane.cursojava.aula37;

public class Teste {

	public static void main(String[] args) {
		
		/*Aluno aluno = new Aluno();
		
		Professor professor = new Professor();
		
		Pessoa pessoa = new Pessoa();
		
		aluno.setNome("Maria");
		*/
		//professor.setTelefoneCelular(telefoneCelular);
		
		Pessoa aluno = new Aluno();
		//aluno.get
		
		Pessoa professor = new Professor();
		//professor.getSala
	}

}
