package com.loiane.cursojava.aula53;

public enum DiaSemana {
	
	SEGUNDA, TERCA, QUARTA, QUINTA, SEXTA, SABADO, DOMINGO;
}
