package com.loiane.cursojava.aula44;

public abstract class Ave extends Animal {

	public abstract void voar();
}
