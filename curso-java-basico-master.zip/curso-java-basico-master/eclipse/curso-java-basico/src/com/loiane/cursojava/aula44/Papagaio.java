package com.loiane.cursojava.aula44;

public class Papagaio extends Ave {

	@Override
	public void voar() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void emitirSom() {
		// TODO Auto-generated method stub
		
	}

}
