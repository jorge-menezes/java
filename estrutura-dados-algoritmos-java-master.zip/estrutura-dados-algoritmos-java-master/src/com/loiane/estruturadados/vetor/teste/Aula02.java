package com.loiane.estruturadados.vetor.teste;

import com.loiane.estruturadados.vetor.Vetor;

public class Aula02 {

	public static void main(String[] args) {
		
		Vetor vetor = new Vetor(5);
	}

}
