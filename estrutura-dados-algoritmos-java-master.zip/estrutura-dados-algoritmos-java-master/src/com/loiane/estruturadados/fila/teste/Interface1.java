package com.loiane.estruturadados.fila.teste;

public interface Interface1 {

	public void adiciona();
	
	public void remove();
}
