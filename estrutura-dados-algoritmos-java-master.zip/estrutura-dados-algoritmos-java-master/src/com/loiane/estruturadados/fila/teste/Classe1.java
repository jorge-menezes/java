package com.loiane.estruturadados.fila.teste;

public class Classe1 implements Interface1{
	
	public void teste(){
		
	}

	@Override
	public void adiciona() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void remove() {
		// TODO Auto-generated method stub
		
	}

}
